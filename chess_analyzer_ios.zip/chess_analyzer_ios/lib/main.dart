
import 'package:flutter/material.dart';

void main() {
  runApp(const ChessAnalyzerApp());
}

class ChessAnalyzerApp extends StatelessWidget {
  const ChessAnalyzerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Chess Analyzer',
      theme: ThemeData.dark(),
      home: const AnalyzerScreen(),
    );
  }
}

class AnalyzerScreen extends StatefulWidget {
  const AnalyzerScreen({super.key});

  @override
  State<AnalyzerScreen> createState() => _AnalyzerScreenState();
}

class _AnalyzerScreenState extends State<AnalyzerScreen> {
  bool engineOn = true;
  int lines = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Chess Analyzer"),
        actions: [
          IconButton(
            icon: const Icon(Icons.list),
            onPressed: () {},
          ),
          PopupMenuButton<String>(
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'flip', child: Text('Flip Board')),
              const PopupMenuItem(value: 'save', child: Text('Save Game')),
              const PopupMenuItem(value: 'theme', child: Text('Change Theme')),
              const PopupMenuItem(value: 'sharefen', child: Text('Share FEN')),
              const PopupMenuItem(value: 'sharepgn', child: Text('Share PGN')),
              const PopupMenuItem(value: 'setup', child: Text('Setup Position')),
            ],
          ),
          PopupMenuButton<String>(
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'sound', child: Text('Sound')),
              const PopupMenuItem(value: 'haptic', child: Text('Haptics')),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Row(
              children: [
                Container(
                  width: 28,
                  margin: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.white),
                  ),
                  child: Column(
                    children: [
                      Expanded(
                        flex: 65,
                        child: Container(color: Colors.white),
                      ),
                      Expanded(
                        flex: 35,
                        child: Container(color: Colors.black),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: AspectRatio(
                    aspectRatio: 1,
                    child: GridView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: 64,
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 8,
                      ),
                      itemBuilder: (context, index) {
                        final row = index ~/ 8;
                        final col = index % 8;
                        final dark = (row + col) % 2 == 1;

                        return Container(
                          color: dark
                              ? Colors.grey.shade700
                              : Colors.grey.shade300,
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),

          Container(
            padding: const EdgeInsets.all(12),
            alignment: Alignment.centerLeft,
            child: Text(
              engineOn
                  ? "Stockfish: +0.7   Best Move: Nf3"
                  : "Engine Paused",
              style: const TextStyle(fontSize: 16),
            ),
          ),

          Expanded(
            child: Container(
              width: double.infinity,
              color: Colors.black54,
              padding: const EdgeInsets.all(10),
              child: const SingleChildScrollView(
                child: Text(
                  "1. e4 e5\n2. Nf3 Nc6\n3. Bb5 a6\n"
                  "(3... Nf6 4. O-O)\n"
                  "(3... d6 4. d4)",
                  style: TextStyle(fontSize: 18),
                ),
              ),
            ),
          ),

          Container(
            padding: const EdgeInsets.all(10),
            color: Colors.black87,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                IconButton(
                  icon: Icon(engineOn ? Icons.pause : Icons.play_arrow),
                  onPressed: () {
                    setState(() {
                      engineOn = !engineOn;
                    });
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.remove),
                  onPressed: () {
                    setState(() {
                      if (lines > 1) lines--;
                    });
                  },
                ),
                Text("Lines: $lines"),
                IconButton(
                  icon: const Icon(Icons.add),
                  onPressed: () {
                    setState(() {
                      lines++;
                    });
                  },
                ),
                const Text("Stockfish"),
              ],
            ),
          )
        ],
      ),
    );
  }
}

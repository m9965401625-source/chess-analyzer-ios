
# Chess Analyzer iOS Starter

## Run

1. Install Flutter
2. Run:
   flutter pub get
   flutter run

## Build iOS

Open in Xcode or run:
flutter build ios
